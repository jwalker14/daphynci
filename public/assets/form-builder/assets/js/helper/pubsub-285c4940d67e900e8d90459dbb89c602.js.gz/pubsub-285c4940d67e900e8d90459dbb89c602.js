define([
       'jquery', 'underscore', 'backbone'
], function($, _, Backbone) {
  return _.extend({}, Backbone.Events);
});
