AmCharts.mapTranslations.kok = {"India":"भारत"}
;
