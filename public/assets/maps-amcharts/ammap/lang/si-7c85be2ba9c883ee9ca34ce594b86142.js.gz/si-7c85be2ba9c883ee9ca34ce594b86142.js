AmCharts.mapTranslations.si = {"Sri Lanka":"ශ්‍රී ලංකාව"}
;
