AmCharts.mapTranslations.sa = {"India":"भारतम्"}
;
