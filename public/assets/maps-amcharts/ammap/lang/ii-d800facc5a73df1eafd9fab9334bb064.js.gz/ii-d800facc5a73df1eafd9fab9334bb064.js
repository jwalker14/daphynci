AmCharts.mapTranslations.ii = {"Brazil":"ꀠꑭ","China":"ꍏꇩ","Germany":"ꄓꇩ","France":"ꃔꇩ","United Kingdom":"ꑱꇩ","India":"ꑴꄗ","Italy":"ꑴꄊꆺ","Japan":"ꏝꀪ","Russia":"ꊉꇆꌦ","United States":"ꂰꇩ","Unknown or Invalid Region":"ꃅꄷꅉꀋꐚꌠ"}
;
