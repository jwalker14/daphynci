AmCharts.mapTranslations.tt = {"Russia":"Россия"}
;
