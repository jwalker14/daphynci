AmCharts.mapTranslations.zu = {"South Africa":"iNingizimu Afrika"}
;
