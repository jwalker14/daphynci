AmCharts.mapTranslations.kk = {"Kazakhstan":"Қазақстан","Tonga":"Тонга"}
;
