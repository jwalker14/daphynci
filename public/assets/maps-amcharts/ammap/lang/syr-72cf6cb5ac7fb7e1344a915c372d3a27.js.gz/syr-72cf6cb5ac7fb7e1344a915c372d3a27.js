AmCharts.mapTranslations.syr = {"Syria":"ܣܘܪܝܝܐ"}
;
