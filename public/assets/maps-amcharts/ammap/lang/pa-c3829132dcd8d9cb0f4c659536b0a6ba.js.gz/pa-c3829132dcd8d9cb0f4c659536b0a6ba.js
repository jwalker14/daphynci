AmCharts.mapTranslations.pa = {"India":"ਭਾਰਤ","Tonga":"TO","Unknown or Invalid Region":"ਅਣਜਾਣ"}
;
