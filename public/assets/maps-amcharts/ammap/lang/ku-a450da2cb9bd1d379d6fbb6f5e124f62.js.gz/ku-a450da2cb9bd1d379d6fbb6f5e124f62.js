AmCharts.mapTranslations.ku = {"Africa":"Cîhan","Turkey":"Tirkiye"}
;
