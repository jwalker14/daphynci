AmCharts.mapTranslations.bs = {"Bosnia and Herzegovina":"Bosna i Hercegovina","Montenegro":"Crna Gora","Serbia":"Srbija","Tonga":"Tonga","Unknown or Invalid Region":"Nepoznata ili nevažeća oblast"}
;
