AmCharts.mapTranslations.kw = {"United Kingdom":"Rywvaneth Unys"}
;
