AmCharts.mapTranslations.mn = {"Brazil":"Бразили","Germany":"Герман","France":"Франц","India":"Энэтхэг","Italy":"Итали","Japan":"Япон","Mongolia":"Монгол улс","Russia":"Орос","Tonga":"Тонга","United States":"Америкийн Нэгдсэн Улс"}
;
