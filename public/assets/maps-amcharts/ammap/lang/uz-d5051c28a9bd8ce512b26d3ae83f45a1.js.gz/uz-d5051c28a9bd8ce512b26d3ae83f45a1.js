AmCharts.mapTranslations.uz = {"Afghanistan":"Афғонистон","Brazil":"Бразилия","China":"Хитой","Germany":"Олмония","France":"Франция","United Kingdom":"Бирлашган Қироллик","India":"Ҳиндистон","Italy":"Италия","Japan":"Япония","Russia":"Россия","United States":"Қўшма Штатлар","Uzbekistan":"Ўзбекистон"}
;
