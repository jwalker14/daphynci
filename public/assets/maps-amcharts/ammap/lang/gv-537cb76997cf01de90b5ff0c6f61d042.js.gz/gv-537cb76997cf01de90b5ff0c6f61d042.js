AmCharts.mapTranslations.gv = {"United Kingdom":"Rywvaneth Unys"}
;
