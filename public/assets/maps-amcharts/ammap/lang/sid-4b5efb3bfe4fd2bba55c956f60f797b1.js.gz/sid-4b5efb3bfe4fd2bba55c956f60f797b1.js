AmCharts.mapTranslations.sid = {"Brazil":"Brazil","China":"China","Germany":"Germany","Ethiopia":"Itiyoophiya","France":"France","United Kingdom":"United Kingdom","India":"India","Italy":"Italy","Japan":"Japan","Russia":"Russia","United States":"United States"}
;
