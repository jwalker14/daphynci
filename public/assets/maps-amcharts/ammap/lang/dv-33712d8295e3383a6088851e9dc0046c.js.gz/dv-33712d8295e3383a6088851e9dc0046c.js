AmCharts.mapTranslations.dv = {"Maldives":"ދިވެހި ރާއްޖެ"}
;
