AmCharts.mapTranslations.tg = {"Afghanistan":"Афғонистан","Tonga":"Тонга"}
;
