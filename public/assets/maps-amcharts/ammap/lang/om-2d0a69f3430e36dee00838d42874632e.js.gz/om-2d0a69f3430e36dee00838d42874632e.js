AmCharts.mapTranslations.om = {"Brazil":"Brazil","China":"China","Germany":"Germany","Ethiopia":"Itoophiyaa","France":"France","United Kingdom":"United Kingdom","India":"India","Italy":"Italy","Japan":"Japan","Kenya":"Keeniyaa","Russia":"Russia","United States":"United States"}
;
