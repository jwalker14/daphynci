AmCharts.mapTranslations.kl = {"Greenland":"Kalaallit Nunaat"}
;
