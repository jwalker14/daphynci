AmCharts.mapTranslations.yo = {"Botswana":"BW","Nigeria":"NG","Tonga":"Tonga"}
;
