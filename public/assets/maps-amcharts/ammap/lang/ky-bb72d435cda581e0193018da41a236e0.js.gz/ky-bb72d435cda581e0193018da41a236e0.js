AmCharts.mapTranslations.ky = {"Kyrgyzstan":"Кыргызстан"}
;
