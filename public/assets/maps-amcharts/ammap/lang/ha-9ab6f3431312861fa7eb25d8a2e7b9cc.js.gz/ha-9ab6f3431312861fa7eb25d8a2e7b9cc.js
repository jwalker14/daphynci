AmCharts.mapTranslations.ha = {"Ghana":"Gaana","Niger":"Nijer","Nigeria":"Nijeriya"}
;
