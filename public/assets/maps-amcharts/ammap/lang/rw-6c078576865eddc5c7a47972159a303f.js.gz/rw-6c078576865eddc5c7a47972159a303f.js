AmCharts.mapTranslations.rw = {"Tonga":"Igitonga"}
;
