
/* A day view with an all-day cell area at the top, and a time grid below
----------------------------------------------------------------------------------------------------------------------*/


fcViews.agendaDay = {
	type: 'agenda',
	duration: { days: 1 }
};
