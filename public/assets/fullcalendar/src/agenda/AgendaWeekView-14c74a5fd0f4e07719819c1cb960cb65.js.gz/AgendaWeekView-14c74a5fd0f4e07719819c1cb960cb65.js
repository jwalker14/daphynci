
/* A week view with an all-day cell area at the top, and a time grid below
----------------------------------------------------------------------------------------------------------------------*/


fcViews.agendaWeek = {
	type: 'agenda',
	duration: { weeks: 1 }
};
