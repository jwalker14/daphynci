
return fc; // export for Node/CommonJS
});
