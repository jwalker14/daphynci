
/* A week view with simple day cells running horizontally
----------------------------------------------------------------------------------------------------------------------*/


fcViews.basicWeek = {
	type: 'basic',
	duration: { weeks: 1 }
};
