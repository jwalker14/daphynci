
/* A view with a single simple day cell
----------------------------------------------------------------------------------------------------------------------*/


fcViews.basicDay = {
	type: 'basic',
	duration: { days: 1 }
};
