
$.fullCalendar.lang("lt", {
	buttonText: {
		month: "Mėnuo",
		week: "Savaitė",
		day: "Diena",
		list: "Darbotvarkė"
	},
	allDayText: "Visą dieną",
	eventLimitText: "daugiau"
});
