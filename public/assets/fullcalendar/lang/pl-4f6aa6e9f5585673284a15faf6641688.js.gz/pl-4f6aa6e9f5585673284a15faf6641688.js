
$.fullCalendar.lang("pl", {
	buttonText: {
		month: "Miesiąc",
		week: "Tydzień",
		day: "Dzień",
		list: "Plan dnia"
	},
	allDayText: "Cały dzień",
	eventLimitText: "więcej"
});
