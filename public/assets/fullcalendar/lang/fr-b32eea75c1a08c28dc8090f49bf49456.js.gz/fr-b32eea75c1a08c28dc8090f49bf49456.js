
$.fullCalendar.lang("fr", {
	buttonText: {
		month: "Mois",
		week: "Semaine",
		day: "Jour",
		list: "Mon planning"
	},
	allDayHtml: "Toute la<br/>journée",
	eventLimitText: "en plus"
});
