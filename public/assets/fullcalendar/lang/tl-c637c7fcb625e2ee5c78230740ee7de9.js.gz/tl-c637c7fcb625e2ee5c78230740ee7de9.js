
$.fullCalendar.lang("tl", {
	buttonText: {
		month: "Buwan",
		week: "Linggo",
		day: "Araw",
		list: "Pakay"
	},
	allDayText: "Lahat ng araw",
	eventLimitText: "dagdag pa"
});
