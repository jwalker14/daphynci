
$.fullCalendar.lang("ar", {
	buttonText: {
		month: "شهر",
		week: "أسبوع",
		day: "يوم",
		list: "أجندة"
	},
	allDayText: "اليوم كله",
	eventLimitText: "أخرى"
});
