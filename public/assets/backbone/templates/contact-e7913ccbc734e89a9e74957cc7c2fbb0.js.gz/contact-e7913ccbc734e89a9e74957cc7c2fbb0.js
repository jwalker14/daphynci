(function() { this.JST || (this.JST = {}); this.JST["backbone/templates/contact"] = function(obj){var __p=[],print=function(){__p.push.apply(__p,arguments);};with(obj||{}){__p.push('Contact Page From JST\n');}return __p.join('');};
}).call(this);
