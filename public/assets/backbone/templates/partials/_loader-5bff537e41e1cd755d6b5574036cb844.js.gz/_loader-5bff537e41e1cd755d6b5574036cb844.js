(function() { this.JST || (this.JST = {}); this.JST["backbone/templates/partials/_loader"] = function(obj){var __p=[],print=function(){__p.push.apply(__p,arguments);};with(obj||{}){__p.push('<div class="spinner">\n  <div class="bounce1"></div>\n  <div class="bounce2"></div>\n  <div class="bounce3"></div>\n</div>\n');}return __p.join('');};
}).call(this);
