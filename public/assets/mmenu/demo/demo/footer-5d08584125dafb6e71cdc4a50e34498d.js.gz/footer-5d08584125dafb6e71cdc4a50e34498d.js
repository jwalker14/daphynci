//	no ad on local files :-)
;
